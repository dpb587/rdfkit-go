git init
git remote add origin https://github.com/rdfa/rdfa.github.io.git
git fetch origin
git reset b388107da8900b6f2a0c42d95ab468e6cf554a4a
